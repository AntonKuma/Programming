import webcam

webcam.run()