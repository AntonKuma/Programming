# uPyCam

For instructions on how to use this, please see [this article](https://lemariva.com/blog/2019/09/micropython-how-about-taking-photo-esp32).
